import React from "react";
import {
  ThemeProvider,
  CssBaseline,
  AppBar,
  Toolbar,
  Typography,
  Container,
  createTheme,
} from "@mui/material";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AiContentPage from "./pages/ai-content-page-new";
import LandingPage from "./pages/landing-page";

const theme = createTheme({
  palette: {
    primary: {
      main: "#1976d2",
    },
    secondary: {
      main: "#dc004e",
    },
    background: {
      default: "#f5f5f5",
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/app" element={<AiContentPage />} />
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App;
