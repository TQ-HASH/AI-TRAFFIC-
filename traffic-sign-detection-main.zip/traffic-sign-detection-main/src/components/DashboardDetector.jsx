// src/components/DashboardDetector.jsx
import React, { useState, useRef } from "react";
import styled from "styled-components";
import { analyzeTrafficSign } from "../utils/trafficSignAPI";
import { processTrafficSignResults } from "../utils/trafficSignAPI";

const MainContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 32px;
  height: 100%;
  width: 100%;
`;

const GlassPanel = styled.div`
  background: rgba(40, 40, 55, 0.85);
  border-radius: 24px;
  box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.45);
  padding: 40px 32px 32px 32px;
  display: flex;
  flex-direction: column;
  min-width: 340px;
  width: 100%;
  overflow-y: auto;
  @media (max-width: 900px) {
    max-width: 100%;
    width: 100%;
    padding: 24px 12px;
  }
`;

const Title = styled.h2`
  color: #fff;
  font-size: 1.6rem;
  font-weight: 600;
  margin-bottom: 12px;
  letter-spacing: 0.5px;
  text-shadow: 0 2px 16px #000, 0 0 8px #00eaff55;
`;

const Divider = styled.div`
  height: 1px;
  width: 100%;
  background: linear-gradient(90deg, #00eaff33 0%, #222 100%);
  margin: 16px 0 24px 0;
`;

const ImageContainer = styled.div`
  position: relative;
  width: 100%;
  height: 320px;
  margin-bottom: 24px;
  border-radius: 16px;
  overflow: hidden;
  background: rgba(20, 20, 30, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
`;

const StyledImage = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
  border-radius: 16px;
`;

const DetectionCard = styled.div`
  padding: 18px 20px;
  background: rgba(30, 30, 40, 0.85);
  border-radius: 12px;
  margin-bottom: 16px;
  box-shadow: 0 2px 12px 0 #00eaff22;
  transition: all 0.3s ease;
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 16px rgba(0, 234, 255, 0.12);
  }
`;

const ConfidenceBar = styled.div`
  height: 8px;
  border-radius: 4px;
  margin-top: 8px;
  background: #222;
  overflow: hidden;
  position: relative;
  &::after {
    content: "";
    display: block;
    height: 100%;
    width: ${({ value }) => value}%;
    background: ${({ value }) =>
      value > 70 ? "#00eaff" : value > 60 ? "#ff9800" : "#9e9e9e"};
    border-radius: 4px;
    transition: width 0.3s;
  }
`;

const Chip = styled.span`
  display: inline-block;
  padding: 4px 12px;
  border-radius: 8px;
  font-size: 0.95rem;
  font-weight: 500;
  background: ${({ color }) => color || "#222"};
  color: #fff;
  margin-right: 8px;
  margin-bottom: 4px;
`;

const DashboardDetector = ({ imageUrl }) => {
  const [trafficSignData, setTrafficSignData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const imageRef = useRef(null);

  const processImage = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      const results = await analyzeTrafficSign(blob);
      const processed = processTrafficSignResults(results);
      setTrafficSignData(processed);
    } catch (error) {
      setError(`Failed to process image: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const getConfidenceColor = (score) => {
    if (score > 0.7) return "#00eaff";
    if (score > 0.6) return "#ff9800";
    return "#9e9e9e";
  };

  const getConfidenceLabel = (score) => {
    if (score > 0.7) return "High Confidence";
    if (score > 0.6) return "Medium Confidence";
    return "Low Confidence";
  };

  return (
    <MainContainer>
      <GlassPanel>
        <Title>Detection Results</Title>
        <Divider />
        <ImageContainer>
          {imageUrl && (
            <StyledImage
              ref={imageRef}
              src={imageUrl}
              alt="Upload preview"
              onLoad={processImage}
            />
          )}
        </ImageContainer>
        {loading && (
          <div style={{ color: "#00eaff", fontWeight: 500, marginBottom: 16 }}>
            Analyzing image...
          </div>
        )}
        {error && (
          <div style={{ color: "#ff5555", fontWeight: 500, marginBottom: 16 }}>
            {error}
          </div>
        )}
        {trafficSignData && !loading && (
          <>
            <div style={{ marginBottom: 16 }}>
              <Chip color="#00eaff55">
                {trafficSignData.length} signs detected
              </Chip>
              <Chip color="#00eaff33">
                {trafficSignData.filter((d) => d.score > 0.7).length} high
                confidence
              </Chip>
            </div>
            {trafficSignData.map((detection, index) => (
              <DetectionCard key={index}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <span style={{ color: "#fff", fontWeight: 500 }}>
                    {detection.label}
                  </span>
                  <Chip color={getConfidenceColor(detection.score) + "33"}>
                    {getConfidenceLabel(detection.score)}
                  </Chip>
                </div>
                <div style={{ marginTop: 8 }}>
                  <span
                    style={{
                      color: "#b0b8d1",
                      fontSize: "0.95rem",
                    }}
                  >
                    Confidence Score
                  </span>
                  <ConfidenceBar value={detection.score * 100} />
                  <span
                    style={{
                      color: "#b0b8d1",
                      float: "right",
                      fontSize: "0.95rem",
                    }}
                  >
                    {(detection.score * 100).toFixed(1)}%
                  </span>
                </div>
              </DetectionCard>
            ))}
          </>
        )}
        {!trafficSignData && !loading && (
          <div
            style={{
              color: "#b0b8d1",
              textAlign: "center",
              marginTop: 32,
            }}
          >
            Upload an image to see detection results
          </div>
        )}
      </GlassPanel>
    </MainContainer>
  );
};

export default DashboardDetector;
