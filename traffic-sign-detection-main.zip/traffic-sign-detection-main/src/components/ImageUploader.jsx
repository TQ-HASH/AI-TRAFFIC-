import React, { useRef, useState, useEffect } from "react";
import { Button, Box, Typography } from "@mui/material";
import { CloudUpload } from "@mui/icons-material";
import styled from "styled-components";
import { FaCameraRetro } from "react-icons/fa";

const UploadContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
  padding: 20px;
  border: 2px dashed #ccc;
  border-radius: 8px;
  background-color: #fafafa;
  transition: all 0.3s ease;

  &:hover {
    border-color: #1976d2;
    background-color: #f0f7ff;
  }
`;

const ImageUploader = ({ onImageUpload }) => {
  const inputRef = useRef(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [showCamera, setShowCamera] = useState(false);
  const [stream, setStream] = useState(null);

  const handleChange = (event) => {
    const file = event.target.files?.[0];

    if (file) {
      // Validate file type
      if (!file.type.startsWith("image/")) {
        alert("Please upload an image file");
        return;
      }

      // Validate file size (e.g., max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert("File size should be less than 5MB");
        return;
      }

      onImageUpload(file);
    }
  };

  const handleTakeImage = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
      setStream(mediaStream);
      setShowCamera(true);
    } catch (err) {
      alert("Could not access camera: " + err.message);
    }
  };

  const handleCapture = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (video && canvas) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      canvas.toBlob(
        (blob) => {
          if (blob) {
            const file = new File([blob], "captured-image.jpg", {
              type: "image/jpeg",
            });
            onImageUpload(file);
          }
        },
        "image/jpeg",
        0.95
      );
      handleCloseCamera();
    }
  };

  const handleCloseCamera = () => {
    setShowCamera(false);
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
  };

  useEffect(() => {
    if (showCamera && videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [showCamera, stream]);

  return (
    <UploadContainer>
      <Button
        variant="contained"
        startIcon={<FaCameraRetro />}
        onClick={handleTakeImage}
      >
        Take Image
      </Button>
      <input
        accept="image/*"
        capture="environment"
        style={{ display: "none" }}
        id="image-upload"
        type="file"
        ref={inputRef}
        onChange={handleChange}
      />
      <label htmlFor="image-upload">
        <Button
          variant="contained"
          component="span"
          startIcon={<CloudUpload />}
        >
          Upload Image
        </Button>
      </label>
      <Typography variant="body2" color="textSecondary">
        Supported formats: JPG, PNG, GIF (max 5MB)
      </Typography>
      {showCamera && (
        <Box
          sx={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            background: "rgba(0,0,0,0.8)",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 9999,
          }}
        >
          <video
            ref={videoRef}
            autoPlay
            playsInline
            style={{
              maxWidth: "90vw",
              maxHeight: "60vh",
              borderRadius: "8px",
              border: "2px solid #fff",
            }}
          />
          <canvas ref={canvasRef} style={{ display: "none" }} />
          <Box sx={{ mt: 2, display: "flex", gap: 2 }}>
            <Button
              variant="contained"
              color="primary"
              onClick={handleCapture}
              startIcon={<CloudUpload />}
            >
              Capture
            </Button>
            <Button
              variant="outlined"
              color="secondary"
              onClick={handleCloseCamera}
            >
              Cancel
            </Button>
          </Box>
        </Box>
      )}
    </UploadContainer>
  );
};

export default ImageUploader;
