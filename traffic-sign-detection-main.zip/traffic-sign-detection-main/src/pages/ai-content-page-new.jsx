import React, { useState } from "react";
import DashboardDetector from "../components/DashboardDetector";
import ImageUploader from "../components/ImageUploader";
import styled from "styled-components";
import { Button } from "@mui/material";
import { useNavigate } from "react-router-dom";

const PageWrapper = styled.div`
  min-height: 100dvh;
  width: 100vw;
  background: url("/images/background.webp") center/cover no-repeat fixed;
  position: relative;
  overflow-x: hidden;

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(10, 10, 20, 0.85);
    z-index: 1;
    backdrop-filter: blur(2px);
  }
`;

const GlassContainer = styled.div`
  position: relative;
  z-index: 2;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: stretch;
  height: 100dvh;
  width: 100vw;
  gap: 32px;
  padding: 48px 32px;
  @media (max-width: 900px) {
    flex-direction: column;
    padding: 24px 8px;
    gap: 24px;
  }
`;

const LeftPanel = styled.div`
  flex: 1.1;
  background: rgba(30, 30, 40, 0.85);
  border-radius: 24px;
  box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.45);
  padding: 40px 32px 32px 32px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
  min-width: 320px;
  max-width: 480px;
  @media (max-width: 900px) {
    max-width: 100%;
    width: 100%;
    align-items: center;
    padding: 24px 12px;
  }
`;

const RightPanel = styled.div`
  flex: 2;
  background: rgba(40, 40, 55, 0.85);
  border-radius: 24px;
  box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.45);
  padding: 40px 32px 32px 32px;
  display: flex;
  flex-direction: column;
  min-width: 340px;
  overflow-y: auto;
  @media (max-width: 900px) {
    max-width: 100%;
    width: 100%;
    padding: 24px 12px;
  }
`;

const Title = styled.h1`
  color: #fff;
  font-size: 2.2rem;
  font-weight: 700;
  margin-bottom: 12px;
  letter-spacing: 1px;
  text-shadow: 0 2px 16px #000, 0 0 8px #00eaff55;
`;

const Description = styled.p`
  color: #e0e0e0;
  font-size: 1.1rem;
  margin-bottom: 32px;
  line-height: 1.6;
`;

const EngineInfo = styled.div`
  color: #b0b8d1;
  font-size: 1rem;
  margin-bottom: 32px;
  background: rgba(20, 20, 30, 0.6);
  border-radius: 12px;
  padding: 18px 20px;
  box-shadow: 0 2px 12px 0 #00eaff22;
`;

const AiContentPage = () => {
  const [imageUrl, setImageUrl] = useState(null);
  const navigate = useNavigate();

  const handleImageUpload = async (file) => {
    try {
      const url = URL.createObjectURL(file);
      setImageUrl(url);
    } catch {
      // handle error if needed
    }
  };

  return (
    <PageWrapper>
      <GlassContainer>
        <LeftPanel>
          <Button
            variant="contained"
            component="span"
            onClick={() => navigate("/")}
          >
            Back
          </Button>
          <Title>Adversarial Image Detector</Title>
          <Description>
            Our model checks for potential adversarial attacks that may confuse
            autonomous systems. Stay informed about how robust your traffic sign
            detections are.
          </Description>
          <EngineInfo>
            <b>Engine:</b> AI-based detection for adversarial image attacks on
            autonomous systems. Fast, accurate, and robust against modern
            threats.
          </EngineInfo>
          <ImageUploader onImageUpload={handleImageUpload} />
        </LeftPanel>
        <RightPanel>
          <DashboardDetector imageUrl={imageUrl} />
        </RightPanel>
      </GlassContainer>
    </PageWrapper>
  );
};

export default AiContentPage;
