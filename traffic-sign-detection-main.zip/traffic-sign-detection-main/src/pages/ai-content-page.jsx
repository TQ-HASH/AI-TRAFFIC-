import React, { useState } from "react";
import {
  Box,
  Paper,
  Typography,
  CircularProgress,
  AppBar,
  Toolbar,
  Container,
} from "@mui/material";
import DashboardDetector from "../components/DashboardDetector";
import ImageUploader from "../components/ImageUploader";
import styled from "styled-components";

const ContentWrapper = styled(Paper)`
  padding: 24px;
  margin-top: 24px;
  border-radius: 12px;
  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
`;

const AppContainer = styled(Container)`
  padding-top: 80px;
  padding-bottom: 40px;
  min-height: 100vh;
  width: 100dvw !important;
  max-width: 100% !important;
  margin-top: ${(props) => props.theme.mixins?.toolbar?.minHeight}px;
`;

const Header = styled(Typography)`
  margin-bottom: 24px;
  text-align: center;
  color: ${(props) => props.theme.palette?.primary?.main};
  text-transform: uppercase;
`;

const AiContentPage = () => {
  const [imageUrl, setImageUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleImageUpload = async (file) => {
    try {
      setIsLoading(true);
      const url = URL.createObjectURL(file);
      setImageUrl(url);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ContentWrapper elevation={0} className="cont">
      <AppContainer maxWidth="lg">
        <AppBar position="fixed">
          <Toolbar>
            <Typography variant="h6">
              AI Based Detection of Adversial Image Attack on Automnomous System
            </Typography>
          </Toolbar>
        </AppBar>
        <Box>
          <Header variant="h4">Traffic Sign & Object Detection</Header>
          <Box mb={4}>
            <ImageUploader onImageUpload={handleImageUpload} />
          </Box>
        </Box>
        <Box>
          {isLoading && (
            <Box display="flex" justifyContent="center" my={4}>
              <CircularProgress />
            </Box>
          )}
          {imageUrl && !isLoading && (
            <Box mt={4}>
              <DashboardDetector imageUrl={imageUrl} />
            </Box>
          )}
        </Box>
      </AppContainer>
    </ContentWrapper>
  );
};

export default AiContentPage;
