import styled from "styled-components";
import { RiExternalLinkLine as LinkIcon } from "react-icons/ri";
import { useNavigate } from "react-router-dom";

const LandingPageWrapper = styled.div`
  width: 100%;
  height: 100dvh;
  position: relative;

  .background__image {
    z-index: 1;
    width: 100dvw;
    height: 100%;
    display: block;
    object-fit: cover;
    object-position: top;
  }

  .overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.6);
    z-index: 2;
  }

  .content {
    z-index: 4;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;

    .title {
      color: #fff;
      text-transform: capitalize;
      margin: 0;
      font-size: 2.8rem;
      text-align: center;
    }

    .description {
      color: #fff;
      text-align: center;
      margin: 7px 0;
      text-align: center;
    }
  }

  .get-started-button {
    position: absolute;
    bottom: 50px;
    left: 50%;
    transform: translateX(-50%);
    padding: 12px 40px;
    z-index: 5;
    border: 2px solid #fff;
    background: transparent;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    min-width: max-content;

    &:hover {
      background: rgba(255, 255, 255, 0.3);
      cursor: pointer;
    }
  }
`;

const LandingPage = () => {
  const navigate = useNavigate();
  return (
    <LandingPageWrapper>
      <img className="background__image" src="/images/background.webp" />
      <div className="overlay" />
      <div className="content">
        <h1 className="title">Adversial Image Detector</h1>
        <p className="description">
          Detect, categorize, and eliminate hostile perturbations
        </p>
      </div>
      <button className="get-started-button" onClick={() => navigate("/app")}>
        <span>Let's Get Started</span>
        <LinkIcon size={20} />
      </button>
    </LandingPageWrapper>
  );
};

export default LandingPage;
