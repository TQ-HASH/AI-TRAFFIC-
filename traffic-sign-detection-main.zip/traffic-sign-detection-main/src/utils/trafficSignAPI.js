const HUGGING_FACE_API_KEY = "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";
const MODEL_ID = "dima806/traffic_sign_detection";

export async function analyzeTrafficSign(imageFile) {
  const apiKey = "bASbtrIG7TqTz5LDtT1c";
  // const project = "road-sign-detection-in-real-time";
  // const version = "3";
  const project = "road-sign-x34x7";
  const version = "2";
  const url = `https://serverless.roboflow.com/${project}/${version}?api_key=${apiKey}`;

  // Convert image file to base64
  const toBase64 = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        // Remove the "data:image/xxx;base64," prefix
        const base64 = reader.result.split(",")[1];
        resolve(base64);
      };
      reader.onerror = (error) => reject(error);
    });

  const imageBase64 = await toBase64(imageFile);

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: imageBase64,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || "Failed to analyze image");
  }

  return await response.json();
}

// Add helper function to process the results
export function processTrafficSignResults(apiResponse) {
  if (!apiResponse || !Array.isArray(apiResponse.predictions)) return [];

  if (apiResponse.predictions.length === 0) {
    return [{ label: "This is an adversial image", score: 0 }];
  }

  return apiResponse.predictions.map((pred) => ({
    label: pred.class,
    score: pred.confidence,
  }));
}
